# 自动驾驶课程

本仓库用于自动驾驶技术课程实践。第一次实践课的 nuScenes 数据处理与 YOLO 视觉目标检测
已完成，正式报告见 [第一次实践课报告](reports/stage01_nuscenes_yolo/stage01_nuscenes_yolo_report.pdf)。
课程材料统一放在 `docs/`，现有第一次实践课的 nuScenes/YOLO 文档和第二次实践课的
`PETR实践指导文档.pdf`。

## 环境

第一次实践使用 `uv` 和 Python 3.12。项目内的 `.venv-stage01` 是软链接，实际环境位于
数据盘的 `/home/yin/data/autonomous_driving/envs/stage01/`。PyTorch wheel 自带
CUDA runtime 与 cuDNN；本机 NVIDIA 驱动支持 CUDA 13.1，因此无需额外安装完整 CUDA
Toolkit。PETR 的 Python 3.8.19 环境位于数据盘的 `envs/stage02/`，项目内的
`.venv-stage02` 也是软链接；两个环境与 `datasets/` 分开。安装包缓存放在数据盘的
`cache/`。

```bash
export UV_CACHE_DIR=/home/yin/data/autonomous_driving/cache/uv
UV_PROJECT_ENVIRONMENT=.venv-stage01 uv sync
source .venv-stage01/bin/activate
```

VS Code 的第一次实践 Python 解释器选择 `.venv-stage01/bin/python`。迁移后已确认
Torch、Ultralytics 和 nuScenes 可以导入，`uv run --no-sync` 可以启动。

## 当前状态

- 本地 GPU 为 NVIDIA GeForce RTX 4060（8 GB）。
- `nuscenes_yolo_converter/`：老师提供的 nuScenes 转 YOLO 代码。
- `yolo_workflow/`：课程提供的 YOLO 训练、评估和可视化代码，以及本次补写的
  `evaluate_cross_location.py`。
- `nuscenes_devkit/`：本次编写的 12 路传感器检查、LiDAR/Radar 投影和 3D 框转 2D 框
  可视化脚本；运行方法见该目录的 README。
- `petr_workflow/`：第二次实践课提供的 PETR 代码包，含课程入口脚本与 `PETR-official/`。
- `reports/`：LaTeX 报告、公共样式和写作准则。
- `data`：指向机械盘 `/home/yin/data/autonomous_driving/datasets` 的软链接。
- nuScenes trainval 元数据、六路相机、顶置 LiDAR、五路 Radar 关键帧，以及四个 YOLO 地区数据集已解压。
- 下载压缩包已在核对解压结果后删除，外部备份由用户自行保留。

## 数据目录

```text
data/
├── nuscenes/
│   ├── maps/
│   ├── samples/
│   └── v1.0-trainval/
└── nuscenes_yolo_vis34/
```

数据解压后，常用路径为：

- 原始 nuScenes：`data/nuscenes`
- Boston YOLO 数据：`data/nuscenes_yolo_vis34/boston-seaport`
- 其他地区数据位于同一目录下。

原始数据包含六路相机与一路顶置 LiDAR，各 40,157 个文件；五路 Radar 关键帧各约
34,147 个文件。Radar 压缩包经检查和解压后已删除，`sweeps/` 中间帧未保留。
转换后的 YOLO 数据共 21,502 对图片与标签，按四个采集地点分别划分为 train、val 和 test。

## 第一次实践课结果

`nuscenes_devkit/inspect_sample.py` 读取同一 sample 的六路相机、LIDAR_TOP 和五路
Radar；`project_lidar_camera.py` 将 LiDAR/Radar 点云叠加到前视图像，并展示三维框到
二维框的转换。报告使用的 scene-0240 样本有 2,983 个 LiDAR 点、48 个 Radar 点落入
前视图像，8 个三维框转换为 8 个二维框。老师已提供转换好的 YOLO 数据，本次只运行
`nuscenes_yolo_converter/validate.py` 校验，没有重新执行全量转换。

## YOLO 训练

`yolo_workflow/train.sh` 使用 Singapore One North 数据集正式训练 YOLO11n：

```bash
./yolo_workflow/train.sh
```

结果目录使用 `YYYYMMDD_HHMMSS_yolo11n_onenorth` 格式。时间戳前缀保证运行记录
按名称自然排序，模型和数据集后缀保持固定；特殊实验才更改后缀。

当前正式训练 `20260916_092702_yolo11n_onenorth` 已完成 50 epochs。验证集最佳结果
出现在第 38 轮：mAP50 为 0.547，mAP50-95 为 0.279。

独立 test 集评估已完成：Precision 为 0.686、Recall 为 0.505、mAP50 为 0.548、
mAP50-95 为 0.288。另已保存 50 张 test 集预测图，结果分别位于：

- `yolo_workflow/runs/evaluation/20260916_095228_yolo11n_onenorth_test_val_test/`
- `yolo_workflow/runs/visualization/20260916_095324_yolo11n_onenorth_test/`

使用最佳权重评估独立 test 集：

```bash
./yolo_workflow/evaluate.sh
```

保存 50 张 test 集预测结果：

```bash
./yolo_workflow/predict.sh
```

## 跨地区泛化实验

使用 One-North 训练得到的 `best.pt` 测试四个地区：

```bash
./yolo_workflow/evaluate_cross_location.sh
```

| 测试地区 | Precision | Recall | mAP50 | mAP50-95 |
|---|---:|---:|---:|---:|
| Boston Seaport | 0.389 | 0.195 | 0.156 | 0.071 |
| Holland Village | 0.665 | 0.430 | 0.445 | 0.275 |
| One-North | 0.686 | 0.505 | 0.548 | 0.288 |
| Queenstown | 0.544 | 0.544 | 0.538 | 0.259 |

三个新加坡地区的 mAP50-95 为 0.259–0.288，Boston 为 0.071。结果保存在
`yolo_workflow/runs/cross_location/`，对比图同时提供 PDF、SVG 和 300 dpi PNG 格式。

## 开始第二次实践课

先读 [PETR 实践指导文档](docs/PETR实践指导文档.pdf)。教程使用 nuScenes mini 的六路相机、
PETR 课程代码和独立的旧版深度学习环境。课程包已从 ModelScope 的
`zlxiao2000/PETR` 下载并解压：代码在 `petr_workflow/`，nuScenes mini 原始数据在数据盘的
`data/nuscenes_mini/`，预训练 ResNet50 权重在 `data/petr_assets/`。原始数据与权重
均不放在 `petr_workflow/`；课程入口和配置已改为直接读取上述数据盘路径。
压缩包内代码与数据文件已核对，无缺失；尚未运行预处理。

第二次实践环境已创建，Python 3.8.19、Torch 1.13.1+cu117 和 torchvision 0.14.1+cu117
已安装。安装 MMCV 1.7.0 时访问 `download.openmmlab.com` 连接超时。网络可用后在仓库
根目录依次运行以下命令，运行时使用自己配置好的代理：

```bash
export UV_CACHE_DIR=/home/yin/data/autonomous_driving/cache/uv
uv pip install --python .venv-stage02/bin/python \
  'mmcv-full==1.7.0' --only-binary mmcv-full \
  --find-links https://download.openmmlab.com/mmcv/dist/cu117/torch1.13.0/index.html
uv pip install --python .venv-stage02/bin/python \
  -r petr_workflow/environment/requirements-linux.txt
cd petr_workflow
../.venv-stage02/bin/python environment/check_environment.py
../.venv-stage02/bin/python preprocess.py
```

`requirements-linux.txt` 从课程 Windows 清单中去掉了已单独安装的 MMCV 和 Windows 专用的
`pywinpty`。环境检查需报告 DCNv2 的 GPU 前向/反向计算通过；预处理应生成 323 帧训练、
81 帧验证索引。随后从 `petr_workflow/` 执行 20 轮训练、mini_val 评估及六相机与俯视图
可视化。新报告
单独放在 `reports/` 下，复用公共模板和
[写作准则](reports/WRITING_GUIDELINES.md)。项目约定见 [AGENT.md](AGENT.md)。
