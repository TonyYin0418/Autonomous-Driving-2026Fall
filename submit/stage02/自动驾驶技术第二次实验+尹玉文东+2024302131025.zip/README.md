# Stage02 PETR 提交源码

运行方法、数据准备、代码来源和实验结果见 petr_workflow/README.md。
本包包含完整 PETR 与 MMDetection3D 源码、环境清单、两次实验的小型结果和报告 LaTeX 源码。
原始数据、预训练权重、训练权重和 Python 环境需另行准备；正式报告 PDF 单独提交。
