# Stage03 PointPillars 提交源码

运行方法及代码来源见 pointpillars_workflow/README.md；
提交清单见 reports/stage03_pointpillars/SUBMISSION.md。
结果包可与本包解压到同一目录，原始 nuScenes 数据及公开权重需另行准备。
